﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um número para a posição {i + 1}");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
                else
                {
                    saida = "\n" + vetor[i] + saida;
                }
            }
            MessageBox.Show($"O resultado é: {saida}");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            string verif = "";
            for (int a = 0; a < 3; a++)
            {
                for (int n = 0; n < 3; n++)
                {
                    verif = Interaction.InputBox($"Digite a {n + 1}° nota do {a + 1}° aluno");

                    if(verif == "")
                    {
                        return;
                    }
                    if (!double.TryParse(verif, out notas[a, n]))
                    {
                        MessageBox.Show("Digite uma nota válida");
                        n--;
                    }
                }
            }
            string media = "";
            for (int i = 0; i < 3; i++)
            {
                media += "\n" + "Aluno " + (i+1) + ":  " + ((notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3).ToString("N2");
            }
            MessageBox.Show(media, "Média", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
        }
}
}
