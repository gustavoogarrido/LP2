﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um número para a posição {i + 1}");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
                else
                {
                    saida = "\n" + vetor[i] + saida;
                }
            }
            MessageBox.Show($"O resultado é: {saida}");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            string verif = "";
            for (int a = 0; a < 3; a++)
            {
                for (int n = 0; n < 3; n++)
                {
                    verif = Interaction.InputBox($"Digite a {n + 1}° nota do {a + 1}° aluno");

                    if(verif == "")
                    {
                        return;
                    }
                    if (!double.TryParse(verif, out notas[a, n]))
                    {
                        MessageBox.Show("Digite uma nota válida");
                        n--;
                    }
                }
            }
            string media = "";
            for (int i = 0; i < 3; i++)
            {
                media += "\n" + "Aluno " + (i+1) + ":  " + ((notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3).ToString("N2");
            }
            MessageBox.Show(media, "Média", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show($"O total é: {Total.ToString()}");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            string list = "";
            int i = lista.Count;
            for (int j = 0; j < i; j++)
            {

                if (lista[j].ToString() == "Otávio")
                {
                    for (i = 7; i < lista.Count; i++)
                    {
                        lista[i - 1] = lista[i];
                        list += "\n" + lista[i - 1];
                    }
                }
                else
                {
                    list += "\n" + lista[j];
                }
            }
            MessageBox.Show(list);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.WindowState = FormWindowState.Normal;
            form2.Show();
        }
    }
}
