﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<string> lista = new List<string>();
            string verif;
            for (int i = 0; i < 3; i++)
            {
                verif = Interaction.InputBox("Digite os nomes: ");
                lista.Add(verif);
                if (verif == "")
                {
                    return;
                }
            }
            foreach(string esp in lista)
            {
                verif = esp.Replace(" ", "");
                list.Items.Add($"O nome: {esp} tem {verif.Length} caracteres");
            }
        }
    }
}
