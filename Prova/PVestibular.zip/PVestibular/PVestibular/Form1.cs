﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int[,] matriz = new int[9, 4];
            int auxiliar;

            for (int curso = 0; curso < 9; curso++)
            {
                auxiliar = 0;
                for (int ano = 0; ano < 4; ano++)
                {
                    if (int.TryParse(Interaction.InputBox("Digite os alunos: "), out matriz[curso, ano]))
                    {
                        lsbxLista.Items.Add($"Total do curso {curso + 1} Ano {ano + 1}: {matriz[curso, ano]}");
                        auxiliar += matriz[curso, ano];
                    }
                    else
                    {
                        ano--;
                    }
                }
                lsbxLista.Items.Add($">>Total Curso: {auxiliar}");
                lsbxLista.Items.Add("----------------------------------------------");
            }
            int soma = 0;
            for (int curso = 0; curso < 9; curso++)
            {
                for (int ano = 0; ano < 4; ano++)
                {
                    soma += matriz[curso, ano];
                }
            }
            lsbxLista.Items.Add($">> Total Geral: {soma}\n");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            lsbxLista.Items.Clear();
        }
    }
}
