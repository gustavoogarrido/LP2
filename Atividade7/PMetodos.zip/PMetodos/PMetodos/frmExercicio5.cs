﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtSorteio_Click(object sender, EventArgs e)
        {
            int n1;
            int n2;

            if (int.TryParse(txt1.Text, out n1) && int.TryParse(txt2.Text, out n2) && n1 > 0 && n2 > 0 && n1 < n2)
            {
                Random obj = new Random();
                int random = obj.Next(n1, n2);

                MessageBox.Show($"O número aleatório é: {random}");
            }
            else
            {
                MessageBox.Show("Dados Inválidos");
            }
        }                                          
    }                                              
}                                                  
                                                   