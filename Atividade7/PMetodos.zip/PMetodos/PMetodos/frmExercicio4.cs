﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void FrmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int j = 0;
            for(var i=0; i<rchbxFrase.Text.Length; i++)
            {
                if (char.IsNumber(rchbxFrase.Text[i]))
                {
                    j++;
                }
            }
            MessageBox.Show($"Quantidade de Números: {j}");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            int i = 0;
            while(i < rchbxFrase.Text.Length)
            {
                if(char.IsWhiteSpace(rchbxFrase.Text[i]))
                {
                    MessageBox.Show($"O primeiro espaço em branco está na posição {i+1}");
                    break;
                }
                i++;
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach(char c in rchbxFrase.Text)
            {
                if(char.IsLetter(c))
                {
                    i++;
                }
            }
            MessageBox.Show($"Número de Letras: {i}");
        }
    }
}
