﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TextBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txtnome_Validated(object sender, EventArgs e)
        {
            double nomen;
            if(txtnome.Text == "" | double.TryParse(txtnome.Text, out nomen))
            {
                errorProvider1.SetError(txtnome, "Insira o Nome");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void Msksalario_Validated(object sender, EventArgs e)
        {
            double salario;
            if (!double.TryParse(msksalario.Text, out salario))
            {
                errorProvider2.SetError(msksalario, "Insira o Salário");
            }
        }

        private void Btverif_Click(object sender, EventArgs e)
        {
            double salario, desinss, desirpf, salfam, liquido;
            if(double.TryParse(msksalario.Text, out salario))
            {
                //Calculo INSS:
                if(salario <= 800.47)
                {
                    desinss = salario * 0.0765;
                    txtINSS.Text = desinss.ToString();
                    txtaliqINSS.Text = "7.65%";
                }
                else if(salario <= 1050)
                {
                    desinss = salario * 0.0865;
                    txtINSS.Text = desinss.ToString();
                    txtaliqINSS.Text = "8.65%";
                }
                else if(salario <= 1400.77)
                {
                    desinss = salario * 0.09;
                    txtINSS.Text = desinss.ToString();
                    txtaliqINSS.Text = "9.00%";
                }
                else if(salario <= 2801.56)
                {
                    desinss = salario * 0.11;
                    txtINSS.Text = desinss.ToString();
                    txtaliqINSS.Text = "11.00%";
                }
                else
                {
                    desinss = 308.17;
                    txtINSS.Text = "308.17";
                    txtaliqINSS.Text = "Teto";
                }

                //Calculo IRPF:
                if (salario <= 1257.12)
                {
                    desirpf = 0;
                    txtIRPF.Text = "Não há desconto";
                    txtaliqIRPF.Text = "Isento";
                }
                else if (salario <= 2512.08)
                {
                    desirpf = salario * 0.15;
                    txtIRPF.Text = desirpf.ToString();
                    txtaliqIRPF.Text = "15,00%";
                }
                else
                {
                    desirpf = salario * 0.275;
                    txtIRPF.Text = desirpf.ToString();
                    txtaliqIRPF.Text = "27,5%";
                }

                //Calculo Salario Familia:
                if(salario <= 435.52)
                {
                    salfam = (double)nupdfilho.Value * 22.33;
                    txtsalariofam.Text = salfam.ToString();
                }
                else if(salario <= 654.61)
                {
                    salfam = (double)nupdfilho.Value * 15.74;
                    txtsalariofam.Text = salfam.ToString();
                }
                else
                {
                    salfam = 0;
                    txtsalariofam.Text = salfam.ToString();
                }
                liquido = salario - desinss - desirpf + salfam;
                txtliquido.Text = liquido.ToString();
            }
            else
            {
                MessageBox.Show("Preencha todos os campos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
