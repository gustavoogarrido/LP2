﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica2
{
    public partial class Form1 : Form
    {
        double num1, num2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Btmais_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtresul.Text = resultado.ToString("N3");
        }

        private void Txtnum1_Validated(object sender, EventArgs e)
        {
            //if(btsair.)
            //else 
            if (!double.TryParse(txtnum1.Text, out num1))
            {
                MessageBox.Show("Número Inválido!");
                txtnum1.Clear();
                txtnum1.Focus();
            }
        }

        private void Btmenos_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtresul.Text = resultado.ToString("N3");
        }

        private void Btvezes_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtresul.Text = resultado.ToString("N3");
        }

        private void Btdiv_Click(object sender, EventArgs e)
        {
            resultado = num1 / num2;
            txtresul.Text = resultado.ToString("N3");
        }

        private void Txtnum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum2.Text, out num2))
            {
                MessageBox.Show("Número Inválido!");
                txtnum2.Clear();
                txtnum2.Focus();
            }
            if(num2 == 0)
            {
                MessageBox.Show("Não é possível dividir por zero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnum2.Clear();
                txtnum2.Focus();
            }
        }

        private void TAB (KeyPressEventArgs press)
        {
            if(press.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                press.Handled = true;
            }
        }
        private void Txtnum1_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Txtnum2_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Txtresul_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Btlimpar_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Btsair_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Btmais_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Btmenos_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Btvezes_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Btdiv_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void Btlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtresul.Clear();
            resultado = 0;
            num1 = 0;
            num2 = 0;
            txtnum1.Focus();
        }

        private void Btsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que você quer sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes);
            {
                Close();
            }
        }
    }
}
