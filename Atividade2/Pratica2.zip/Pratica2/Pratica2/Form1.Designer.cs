﻿namespace Pratica2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnum1 = new System.Windows.Forms.Label();
            this.lblnum2 = new System.Windows.Forms.Label();
            this.lblresul = new System.Windows.Forms.Label();
            this.txtnum1 = new System.Windows.Forms.TextBox();
            this.txtnum2 = new System.Windows.Forms.TextBox();
            this.txtresul = new System.Windows.Forms.TextBox();
            this.btlimpar = new System.Windows.Forms.Button();
            this.btsair = new System.Windows.Forms.Button();
            this.btmais = new System.Windows.Forms.Button();
            this.btmenos = new System.Windows.Forms.Button();
            this.btvezes = new System.Windows.Forms.Button();
            this.btdiv = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblnum1
            // 
            this.lblnum1.AutoSize = true;
            this.lblnum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnum1.Location = new System.Drawing.Point(77, 52);
            this.lblnum1.Name = "lblnum1";
            this.lblnum1.Size = new System.Drawing.Size(94, 24);
            this.lblnum1.TabIndex = 0;
            this.lblnum1.Text = "Número 1";
            // 
            // lblnum2
            // 
            this.lblnum2.AutoSize = true;
            this.lblnum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnum2.Location = new System.Drawing.Point(77, 123);
            this.lblnum2.Name = "lblnum2";
            this.lblnum2.Size = new System.Drawing.Size(94, 24);
            this.lblnum2.TabIndex = 1;
            this.lblnum2.Text = "Número 2";
            // 
            // lblresul
            // 
            this.lblresul.AutoSize = true;
            this.lblresul.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresul.Location = new System.Drawing.Point(77, 200);
            this.lblresul.Name = "lblresul";
            this.lblresul.Size = new System.Drawing.Size(94, 24);
            this.lblresul.TabIndex = 2;
            this.lblresul.Text = "Resultado";
            this.lblresul.Click += new System.EventHandler(this.Label3_Click);
            // 
            // txtnum1
            // 
            this.txtnum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum1.Location = new System.Drawing.Point(215, 55);
            this.txtnum1.Name = "txtnum1";
            this.txtnum1.Size = new System.Drawing.Size(197, 26);
            this.txtnum1.TabIndex = 1;
            this.txtnum1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtnum1_KeyPress);
            this.txtnum1.Validated += new System.EventHandler(this.Txtnum1_Validated);
            // 
            // txtnum2
            // 
            this.txtnum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum2.Location = new System.Drawing.Point(215, 128);
            this.txtnum2.Name = "txtnum2";
            this.txtnum2.Size = new System.Drawing.Size(197, 26);
            this.txtnum2.TabIndex = 2;
            this.txtnum2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtnum2_KeyPress);
            this.txtnum2.Validated += new System.EventHandler(this.Txtnum2_Validated);
            // 
            // txtresul
            // 
            this.txtresul.Enabled = false;
            this.txtresul.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtresul.Location = new System.Drawing.Point(215, 205);
            this.txtresul.Name = "txtresul";
            this.txtresul.Size = new System.Drawing.Size(197, 26);
            this.txtresul.TabIndex = 3;
            this.txtresul.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtresul_KeyPress);
            // 
            // btlimpar
            // 
            this.btlimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlimpar.Location = new System.Drawing.Point(572, 52);
            this.btlimpar.Name = "btlimpar";
            this.btlimpar.Size = new System.Drawing.Size(164, 71);
            this.btlimpar.TabIndex = 4;
            this.btlimpar.Text = "Limpar";
            this.btlimpar.UseVisualStyleBackColor = true;
            this.btlimpar.Click += new System.EventHandler(this.Btlimpar_Click);
            // 
            // btsair
            // 
            this.btsair.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btsair.Location = new System.Drawing.Point(572, 154);
            this.btsair.Name = "btsair";
            this.btsair.Size = new System.Drawing.Size(164, 71);
            this.btsair.TabIndex = 5;
            this.btsair.Text = "Sair";
            this.btsair.UseVisualStyleBackColor = true;
            this.btsair.Click += new System.EventHandler(this.Btsair_Click);
            // 
            // btmais
            // 
            this.btmais.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmais.Location = new System.Drawing.Point(28, 298);
            this.btmais.Name = "btmais";
            this.btmais.Size = new System.Drawing.Size(164, 71);
            this.btmais.TabIndex = 6;
            this.btmais.Text = "+";
            this.btmais.UseVisualStyleBackColor = true;
            this.btmais.Click += new System.EventHandler(this.Btmais_Click);
            // 
            // btmenos
            // 
            this.btmenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmenos.Location = new System.Drawing.Point(215, 298);
            this.btmenos.Name = "btmenos";
            this.btmenos.Size = new System.Drawing.Size(164, 71);
            this.btmenos.TabIndex = 7;
            this.btmenos.Text = "-";
            this.btmenos.UseVisualStyleBackColor = true;
            this.btmenos.Click += new System.EventHandler(this.Btmenos_Click);
            // 
            // btvezes
            // 
            this.btvezes.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btvezes.Location = new System.Drawing.Point(399, 298);
            this.btvezes.Name = "btvezes";
            this.btvezes.Size = new System.Drawing.Size(164, 71);
            this.btvezes.TabIndex = 8;
            this.btvezes.Text = "*";
            this.btvezes.UseVisualStyleBackColor = true;
            this.btvezes.Click += new System.EventHandler(this.Btvezes_Click);
            // 
            // btdiv
            // 
            this.btdiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btdiv.Location = new System.Drawing.Point(587, 298);
            this.btdiv.Name = "btdiv";
            this.btdiv.Size = new System.Drawing.Size(164, 71);
            this.btdiv.TabIndex = 9;
            this.btdiv.Text = "/";
            this.btdiv.UseVisualStyleBackColor = true;
            this.btdiv.Click += new System.EventHandler(this.Btdiv_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btdiv);
            this.Controls.Add(this.btvezes);
            this.Controls.Add(this.btmenos);
            this.Controls.Add(this.btmais);
            this.Controls.Add(this.btsair);
            this.Controls.Add(this.btlimpar);
            this.Controls.Add(this.txtresul);
            this.Controls.Add(this.txtnum2);
            this.Controls.Add(this.txtnum1);
            this.Controls.Add(this.lblresul);
            this.Controls.Add(this.lblnum2);
            this.Controls.Add(this.lblnum1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnum1;
        private System.Windows.Forms.Label lblnum2;
        private System.Windows.Forms.Label lblresul;
        private System.Windows.Forms.TextBox txtnum1;
        private System.Windows.Forms.TextBox txtnum2;
        private System.Windows.Forms.TextBox txtresul;
        private System.Windows.Forms.Button btlimpar;
        private System.Windows.Forms.Button btsair;
        private System.Windows.Forms.Button btmais;
        private System.Windows.Forms.Button btmenos;
        private System.Windows.Forms.Button btvezes;
        private System.Windows.Forms.Button btdiv;
    }
}

