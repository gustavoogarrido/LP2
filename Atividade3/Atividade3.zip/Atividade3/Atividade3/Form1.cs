﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MaskedTextBox1_Validated(object sender, EventArgs e)
        {

        }
        
        private void Mskpeso_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskpeso, "");
            if(!double.TryParse(mskpeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("Peso Inválido");
                errorProvider1.SetError(mskpeso, "Peso Inválido");
            }
        }

        private void Mskaltura_Validated(object sender, EventArgs e)
        {
            double altura;
            errorProvider2.SetError(mskaltura, "");
            if (!double.TryParse(mskaltura.Text, out altura) || altura<= 0)
            {
                MessageBox.Show("Altura Inválida");
                errorProvider1.SetError(mskaltura, "Altura Inválida");
            }
        }

        private void Btcalc_Click(object sender, EventArgs e)
        {
            double IMC, altura, peso;
            if (Double.TryParse(mskpeso.Text, out peso) && Double.TryParse(mskaltura.Text, out altura))
            {
                if (altura <= 0 || peso <= 0)
                {
                    MessageBox.Show("Valores inseridos devem ser maior que zero");
                }
                else
                {
                    IMC = peso / Math.Pow(altura, 2);
                    IMC = Math.Round(IMC, 1);
                    txtimc.Text = IMC.ToString();
                    if(IMC < 18.5)
                    {
                        MessageBox.Show("Classificação: Magreza");
                    }
                    else
                    {
                        if(IMC <= 24.9)
                        {
                            MessageBox.Show("Classificação: Normal");
                        }
                        else
                            if(IMC <= 29.9)
                            {
                            MessageBox.Show("Classificação: Sobrepeso");
                            }
                            else
                                if(IMC <= 39.9)
                                {
                                    MessageBox.Show("Classificação: Obesidade");
                                }
                                else
                                {
                            MessageBox.Show("Obesidade Grave");
                        }
                    }
                }
            }
        }

        private void Btllimpar_Click(object sender, EventArgs e)
        {
            mskpeso.Clear();
            mskaltura.Clear();
            txtimc.Clear();
        }

        private void Btsair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
