﻿namespace Atividade3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.mskpeso = new System.Windows.Forms.MaskedTextBox();
            this.mskaltura = new System.Windows.Forms.MaskedTextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.btcalc = new System.Windows.Forms.Button();
            this.btllimpar = new System.Windows.Forms.Button();
            this.btsair = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(245, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Peso Atual:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(287, 162);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Altura:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(302, 279);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "IMC:";
            // 
            // mskpeso
            // 
            this.mskpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskpeso.Location = new System.Drawing.Point(374, 34);
            this.mskpeso.Margin = new System.Windows.Forms.Padding(6);
            this.mskpeso.Mask = "900.00";
            this.mskpeso.Name = "mskpeso";
            this.mskpeso.Size = new System.Drawing.Size(316, 29);
            this.mskpeso.TabIndex = 3;
            this.mskpeso.Validated += new System.EventHandler(this.Mskpeso_Validated);
            // 
            // mskaltura
            // 
            this.mskaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskaltura.Location = new System.Drawing.Point(374, 162);
            this.mskaltura.Margin = new System.Windows.Forms.Padding(6);
            this.mskaltura.Mask = "0.00";
            this.mskaltura.Name = "mskaltura";
            this.mskaltura.Size = new System.Drawing.Size(316, 29);
            this.mskaltura.TabIndex = 4;
            this.mskaltura.Validated += new System.EventHandler(this.Mskaltura_Validated);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtimc.Location = new System.Drawing.Point(374, 279);
            this.txtimc.Margin = new System.Windows.Forms.Padding(6);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(316, 29);
            this.txtimc.TabIndex = 5;
            // 
            // btcalc
            // 
            this.btcalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcalc.Location = new System.Drawing.Point(178, 431);
            this.btcalc.Margin = new System.Windows.Forms.Padding(6);
            this.btcalc.Name = "btcalc";
            this.btcalc.Size = new System.Drawing.Size(260, 118);
            this.btcalc.TabIndex = 6;
            this.btcalc.Text = "Calcular";
            this.btcalc.UseVisualStyleBackColor = true;
            this.btcalc.Click += new System.EventHandler(this.Btcalc_Click);
            // 
            // btllimpar
            // 
            this.btllimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btllimpar.Location = new System.Drawing.Point(526, 431);
            this.btllimpar.Margin = new System.Windows.Forms.Padding(6);
            this.btllimpar.Name = "btllimpar";
            this.btllimpar.Size = new System.Drawing.Size(260, 118);
            this.btllimpar.TabIndex = 7;
            this.btllimpar.Text = "Limpar";
            this.btllimpar.UseVisualStyleBackColor = true;
            this.btllimpar.Click += new System.EventHandler(this.Btllimpar_Click);
            // 
            // btsair
            // 
            this.btsair.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btsair.Location = new System.Drawing.Point(886, 431);
            this.btsair.Margin = new System.Windows.Forms.Padding(6);
            this.btsair.Name = "btsair";
            this.btsair.Size = new System.Drawing.Size(260, 118);
            this.btsair.TabIndex = 8;
            this.btsair.Text = "Sair";
            this.btsair.UseVisualStyleBackColor = true;
            this.btsair.Click += new System.EventHandler(this.Btsair_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1467, 831);
            this.Controls.Add(this.btsair);
            this.Controls.Add(this.btllimpar);
            this.Controls.Add(this.btcalc);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.mskaltura);
            this.Controls.Add(this.mskpeso);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox mskpeso;
        private System.Windows.Forms.MaskedTextBox mskaltura;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.Button btcalc;
        private System.Windows.Forms.Button btllimpar;
        private System.Windows.Forms.Button btsair;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
    }
}

