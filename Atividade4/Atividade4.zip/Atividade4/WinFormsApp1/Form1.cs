using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            double A;
            if (!double.TryParse(txtA.Text, out A))
            {
                MessageBox.Show("Insira um N�mero");
                errorProvider1.SetError(txtA, "Insira um N�mero");
            }
            else
            {
                if (A <= 0)
                {
                    MessageBox.Show("N�mero Inv�lido");
                    errorProvider1.SetError(txtA, "N�mero Inv�lido");
                }
                else
                {
                    errorProvider1.Clear();
                }
            }
        }
        private void TAB(KeyPressEventArgs press)
        {
            if (press.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                press.Handled = true;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtResul.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            double B;
            if (!double.TryParse(txtB.Text, out B))
            {
                MessageBox.Show("Insira um N�mero");
                errorProvider2.SetError(txtB, "Insira um N�mero");
            }
            else
            {
                if (B <= 0)
                {
                    MessageBox.Show("N�mero Inv�lido");
                    errorProvider2.SetError(txtB, "N�mero Inv�lido");
                }
                else
                {
                    errorProvider2.Clear();
                }
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            double C;
            if (!double.TryParse(txtC.Text, out C))
            {
                MessageBox.Show("Insira um N�mero");
                errorProvider3.SetError(txtC, "Insira um N�mero");
            }
            else
            {
                if (C <= 0)
                {
                    MessageBox.Show("N�mero Inv�lido");
                    errorProvider3.SetError(txtC, "N�mero Inv�lido");
                }
                else
                {
                    errorProvider3.Clear();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double A, B, C;
            if (double.TryParse(txtA.Text, out A) && double.TryParse(txtB.Text, out B) && double.TryParse(txtC.Text, out C))
            {
                if (Math.Abs(B - C) < A && A < B + C && Math.Abs(A - C) < B && B < A + C && Math.Abs(A - B) < C && C < A + B)
                {
                    if (A == B && A != C || A == C && A != B || B == C && B != A)
                    {
                        txtResul.Text = "Tri�ngulo Is�sceles";
                    }
                    else if (A == B && A == C)
                    {
                        txtResul.Text = "Tri�ngulo Equil�tero";
                    }
                    else
                    {
                        txtResul.Text = "Tri�ngulo Escaleno";
                    }
                }
                else
                {
                    txtResul.Text = "N�o � tri�ngulo";
                }
            }
        }

        private void button3_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtB_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void txtC_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void txtResul_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void button3_KeyPress_1(object sender, KeyPressEventArgs e)
        {

        }

        private void txtA_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }
    }
}