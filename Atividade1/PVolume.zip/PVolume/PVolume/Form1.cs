﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;

        private void TxtAltura_Validating(object sender, CancelEventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                lblErro1.Visible = true;
                lblErro1.Text = "Raio inválido";
            }
            else
            {
                if (raio <= 0)
                {
                    lblErro1.Visible = true;
                    lblErro1.Text = "O raio deve ser maior que zero";
                }
            }
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                lblErro2.Visible = true;
                lblErro2.Text = "Altura inválido";
            }
            else
            {
                if (raio <= 0)
                {
                    lblErro2.Visible = true;
                    lblErro2.Text = "A altura deve ser maior que zero";
                }
            }
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");
        }

        private void TxtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void LblErro1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
            lblErro1.Visible = false;
            lblErro2.Visible = false;
        }

        private void TxtRaio_Validating(object sender, CancelEventArgs e)
        {
            
        }
    }
}
